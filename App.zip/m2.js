import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import footImage from './foot2.jpeg'; // foot2.jpeg 파일을 임포트합니다.

function M2() {
  const navigate = useNavigate();

  const handleConfirm = () => {
    // 여기에 "확인" 버튼을 눌렀을 때 처리할 로직을 추가하세요.
    // 예를 들어, 아이디와 비밀번호 검증 등을 수행할 수 있습니다.
    // 이후에 `navigate('/app1')`을 호출하여 `App1.js`로 이동합니다.
    // 임시로 아래 코드를 사용하여 페이지 이동을 확인할 수 있습니다.
    navigate('/m3');
  };

  return (
    <div style={{ backgroundColor: 'white', textAlign: 'center', padding: '120px', display: 'flex', alignItems: 'center', flexDirection: 'column', position: 'relative' }}>
      <Link to="/">
        <img src={footImage} alt="Footer" style={{ position: 'absolute', top: '50px', left: '50%', transform: 'translateX(-50%)', width: '100px', opacity: 0.5, cursor: 'pointer' }} />
      </Link>
      <h1 style={{ color: 'black' }}>로그인</h1>

      <div style={{ borderBottom: '2px solid black', width: '100%', marginBottom: '120px' }}></div>

      <div style={{ display: 'flex', flexDirection: 'column', marginBottom: '10px', alignItems: 'center' }}>
        <div style={{ display: 'flex', flexDirection: 'column', marginBottom: '10px', alignItems: 'center' }}>
          <input type="text" placeholder="아이디" style={{ padding: '10px', width: '300px', marginRight: '5px' }} />
          <input type="password" placeholder="비밀번호" style={{ padding: '10px', width: '300px', marginRight: '5px' }} />
          <button onClick={handleConfirm} style={{ padding: '10px 20px', backgroundColor: 'orange', border: 'none', fontSize: '16px', cursor: 'pointer', color: 'blue' }}>확인</button>
        </div>
        <Link to="/signup">
          <button style={{ padding: '10px 20px', backgroundColor: 'transparent', border: 'none', fontSize: '16px', cursor: 'pointer', color: 'blue' }}>회원가입으로 가기</button>
        </Link>
      </div>
    </div>
  );
}

export default M2;
