import React from 'react';
import { Link } from 'react-router-dom';
import footImage from './foot2.jpeg'; // foot2.jpeg 파일을 임포트합니다.

function M1() {
  return (
    <div style={{ backgroundColor: 'white', textAlign: 'center', display: 'flex', alignItems: 'center', flexDirection: 'column' }}>
      {/* foot2.jpeg 누르면 App.js로 이동하는 링크 */}
      <Link to="/app">
        <img src={footImage} alt="Go to App" style={{ width: '100px', cursor: 'pointer', marginTop: '20px' }} />
      </Link>
      <div style={{ backgroundColor: 'orange', width: '100%', textAlign: 'center', padding: '20px' }}>
        <h1 style={{ color: 'white' }}>회원가입</h1>
      </div>
      {/* 사용자 정보 */}
      <div style={{ borderBottom: '2px solid white', width: '100%', marginBottom: '20px' }}></div>
      <div style={{ padding: '20px', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        {/* 사용자 정보 입력 폼 */}
        <div style={{ display: 'flex', flexDirection: 'row', marginBottom: '10px', alignItems: 'center' }}>
          <input type="text" placeholder="아이디" style={{ padding: '10px', marginRight: '5px' }} />
          <button style={{ padding: '10px 20px' }}>중복확인</button>
        </div>
        <input type="text" placeholder="이메일" style={{ padding: '10px', marginBottom: '5px' }} />
        <input type="password" placeholder="비밀번호" style={{ padding: '10px', marginBottom: '5px' }} />
        <input type="password" placeholder="비밀번호 확인" style={{ padding: '10px', marginBottom: '5px' }} />
        {/* 애완견 정보 */}
        <div style={{ backgroundColor: 'white', width: '100%', padding: '20px', marginBottom: '20px' }}>
          <h2>애완견 정보</h2>
          {/* 4개의 입력 필드 */}
          <div style={{ display: 'flex', flexDirection: 'column', marginBottom: '10px', alignItems: 'center' }}>
            <div style={{ display: 'flex', flexDirection: 'row', marginBottom: '10px', alignItems: 'center' }}>
              <label style={{ marginRight: '5px' }}>이름:</label>
              <input type="text" style={{ padding: '5px' }} />
            </div>
            <div style={{ display: 'flex', flexDirection: 'row', marginBottom: '10px', alignItems: 'center' }}>
              <label style={{ marginRight: '5px' }}>견종:</label>
              <input type="text" style={{ padding: '5px' }} />
            </div>
            <div style={{ display: 'flex', flexDirection: 'row', marginBottom: '10px', alignItems: 'center' }}>
              <label style={{ marginRight: '5px' }}>나이:</label>
              <input type="text" style={{ padding: '5px' }} />
            </div>
            <div style={{ display: 'flex', flexDirection: 'row', marginBottom: '10px', alignItems: 'center' }}>
              <label style={{ marginRight: '5px' }}>몸무게:</label>
              <input type="text" style={{ padding: '5px' }} />
            </div>
          </div>
        </div>
        {/* 가입하기 버튼 */}
        <button style={{ padding: '10px 20px', backgroundColor: 'orange', border: 'none', fontSize: '16px', cursor: 'pointer', color: 'black' }}>가입하기</button>
      </div>
    </div>
  );
}

export default M1;
