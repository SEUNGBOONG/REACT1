import React from 'react';
import { useNavigate } from 'react-router-dom';

function M2() {
  const navigate = useNavigate();

  const handleConfirm = () => {
    // 여기에 "확인" 버튼을 눌렀을 때 처리할 로직을 추가하세요.
    // 예를 들어, 아이디와 비밀번호 검증 등을 수행할 수 있습니다.
    // 이후에 `navigate('/m3')`을 호출하여 `m3.js`로 이동합니다.
    // 임시로 아래 코드를 사용하여 페이지 이동을 확인할 수 있습니다.
    navigate('/m3');
  };

  return (
    <div style={{ backgroundColor: 'white', textAlign: 'center', padding: '20px', display: 'flex', alignItems: 'center', flexDirection: 'column' }}>
      <h1 style={{ color: 'black' }}>로그인</h1>
      <div style={{ borderBottom: '2px solid black', width: '100%', marginBottom: '20px' }}></div>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <div style={{ display: 'flex', flexDirection: 'row', marginBottom: '10px', alignItems: 'center' }}>
          <input type="text" placeholder="아이디" style={{ padding: '10px', marginRight: '5px' }} />
          <input type="password" placeholder="비밀번호" style={{ padding: '10px', marginRight: '5px' }} />
          <button onClick={handleConfirm} style={{ padding: '10px 20px', backgroundColor: 'orange', border: 'none', fontSize: '16px', cursor: 'pointer', color: 'blue' }}>확인</button>
        </div>
        <button style={{ padding: '10px 20px', backgroundColor: 'transparent', border: 'none', fontSize: '16px', cursor: 'pointer', color: 'blue' }}>회원가입으로 가기</button>
      </div>
    </div>
  );
}

export default M2;
