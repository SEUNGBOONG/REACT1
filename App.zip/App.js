import React from 'react';
import { Link, Route, BrowserRouter as Router, Routes, Outlet, Navigate } from 'react-router-dom';

import BannerImage from './1.jpg';
import M1 from './m1'; // m1.js 파일을 임포트합니다.
import M2 from './m2'; // m2.js 파일을 임포트합니다.
import suImage from './su.jpeg'; // su.jpeg 파일을 임포트합니다.
import thImage from './th1.jpeg'; 
import puImage from './pu.jpeg'; 

function Home() {
  const profileData = [
    { label: '성별', value: '수컷' },
    { label: '나이', value: 3 },
    { label: '견종', value: '비숑' },
    { label: '몸무게', value: '5kg' },
  ];

  return (
    <div>
      <div style={{ textAlign: 'center', backgroundColor: 'orange', padding: '20px' }}>
        {/* 이미지를 원형으로 바꾸고 크기를 절반으로 조정 */}
        <div style={{ borderRadius: '50%', overflow: 'hidden', maxWidth: '250px', margin: '0 auto' }}>
          <img
            src={process.env.PUBLIC_URL + BannerImage}
            alt="홈 화면 배너"
            style={{ width: '100%', height: 'auto' }}
          />
        </div>
        <h1 style={{ color: 'white' }}>배변패드를 활용한 애견 건강 확인하기</h1>
      </div>
      <div style={{ textAlign: 'center' }}>
        <h2>애견 프로필</h2>
        <div style={{ width: '200px', margin: '0 auto', borderBottom: '1px solid black', marginBottom: '20px' }}></div>
        {/* 원하는 텍스트를 추가하세요 */}
      </div>
      <div style={{ backgroundColor: 'lightgray', height: '200px', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        {profileData.map((data, index) => (
          <p key={index}>
            <strong style={{ color: 'yellow' }}>{data.label}:</strong> {data.value}
          </p>
        ))}
      </div>
      <div style={{ textAlign: 'center' }}>
        <h2>건강 상태</h2>
        <div style={{ width: '200px', margin: '0 auto', borderBottom: '1px solid black', marginBottom: '20px' }}></div>
        {/* 원하는 텍스트를 추가하세요 */}
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-around' }}>
        <div style={{ border: '1px solid black', width: '200px', height: '150px', background: `url(${suImage}) center/cover no-repeat` }}>
          수분량
        </div>
        <div style={{ border: '1px solid black', width: '200px', height: '150px', background: `url(${thImage}) center/cover no-repeat` }}>
          온도
        </div>
        <div style={{ border: '1px solid black', width: '200px', height: '150px', background: `url(${puImage}) center/cover no-repeat` }}>
          변색깔
        </div>
      </div>
      {/* 건강 측정 버튼 추가 */}
      <div>
        <div style={{ textAlign: 'center', backgroundColor: 'orange', padding: '10px', height: '90px' }}>
          <h1 style={{ color: 'white' }}>
            <button
              style={{ color: 'white', backgroundColor: 'transparent', border: 'none', fontSize: '24px', padding: '10px 20px' }}
              onClick={() => {
                // 버튼이 클릭되었을 때 실행될 동작을 여기에 작성하세요
                console.log('버튼이 클릭되었습니다.');
              }}
            >
              건강 측정하기
            </button>
          </h1>
        </div>
      </div>
    </div>
  );
}

// 나머지 코드는 동일하게 유지됩니다.

function App() {
  return (
    <Router>
      {/* 로그인과 회원가입 버튼 추가 */}
      <div style={{ textAlign: 'right', padding: '10px' }}>
        <Link to="/signup" style={{ textDecoration: 'none', margin: '0 10px', color: 'black' }}>회원가입</Link>
        <Link to="/login" style={{ textDecoration: 'none', margin: '0 10px', color: 'black' }}>로그인</Link>
      </div>
      <Routes>
        {/* 회원가입 버튼 클릭 시 m1.js로 이동하도록 설정 */}
        <Route path="/signup" element={<M1 />} />
        {/* 로그인 버튼 클릭 시 m2.js로 이동하도록 설정 */}
        <Route path="/login" element={<M2 />} />
        <Route path="/" element={<Home />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </Router>
  );
}

export default App;
